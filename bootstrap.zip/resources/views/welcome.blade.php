@extends('layouts.app')

@section('content')
    <div class="row">
        Welcome to my portal. Enjoy the navigation
    </div>
@endsection