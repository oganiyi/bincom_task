@include('layouts.header')

    <!-- Begin Page Content -->
    <div class="container my-5">

        @yield('content')
    </div>
    <!-- /.container-fluid -->



@include('layouts.footer')